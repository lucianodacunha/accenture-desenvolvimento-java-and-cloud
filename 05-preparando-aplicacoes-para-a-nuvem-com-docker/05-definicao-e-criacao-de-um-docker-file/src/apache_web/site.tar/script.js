// Mobile menu toggle
const toggle = document.querySelector('.nav__toggle');
const nav = document.getElementById('nav');
if (toggle && nav) {
	toggle.addEventListener('click', () => {
		const isOpen = nav.classList.toggle('is-open');
		toggle.setAttribute('aria-expanded', String(isOpen));
	});
}

// Smooth scroll for internal links
document.querySelectorAll('a[href^="#"]').forEach((link) => {
	link.addEventListener('click', (e) => {
		const href = link.getAttribute('href');
		if (!href || href === '#') return;
		const target = document.querySelector(href);
		if (target) {
			e.preventDefault();
			target.scrollIntoView({ behavior: 'smooth', block: 'start' });
			// close mobile menu on navigation
			nav?.classList.remove('is-open');
			toggle?.setAttribute('aria-expanded', 'false');
		}
	});
});

// Year in footer
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = String(new Date().getFullYear());

// Toast helper
const toastEl = document.getElementById('toast');
function showToast(message, { error = false } = {}) {
	if (!toastEl) return;
	toastEl.textContent = message;
	toastEl.classList.remove('toast--error');
	if (error) toastEl.classList.add('toast--error');
	toastEl.classList.add('toast--show');
	setTimeout(() => toastEl.classList.remove('toast--show'), 2600);
}

// Simple form handling
const form = document.getElementById('leadForm');
if (form) {
	form.addEventListener('submit', (e) => {
		e.preventDefault();
		const data = new FormData(form);
		const name = (data.get('name') || '').toString().trim();
		const email = (data.get('email') || '').toString().trim();

		if (!name) {
			showToast('Por favor, informe seu nome.', { error: true });
			return;
		}
		const emailOk = /.+@.+\..+/.test(email);
		if (!emailOk) {
			showToast('Informe um e‑mail válido.', { error: true });
			return;
		}

		// Simula envio e armazena localmente
		try {
			const leads = JSON.parse(localStorage.getItem('leads') || '[]');
			leads.push({ name, email, ts: Date.now() });
			localStorage.setItem('leads', JSON.stringify(leads));
		} catch {}

		form.reset();
		showToast('Inscrição registrada! Em breve entraremos em contato.');
	});
}
